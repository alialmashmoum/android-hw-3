package com.example.hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button a = findViewById(R.id.button2);
        final EditText s = findViewById(R.id.editTextTextPersonName);
        final EditText d = findViewById(R.id.editTextNumber);
        final EditText f = findViewById(R.id.editTextTextPersonName5);
        final EditText g = findViewById(R.id.editTextPhone);
        final EditText h = findViewById(R.id.editTextTextEmailAddress);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = s.getText().toString();
                String age = d.getText().toString();
                String y = f.getText().toString();
                String p = g.getText().toString();
                String Email = h.getText().toString();
                Intent z = new Intent(MainActivity.this , MainActivity2.class);
                z.putExtra("info",name);
                z.putExtra("age1",age);
                z.putExtra("job1",y);
                z.putExtra("phone",p);
                z.putExtra("email1",Email);
                startActivity(z);
            }
        });
    }
}