package com.example.hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView name = findViewById(R.id.textView2);
        TextView age = findViewById(R.id.textView3);
        TextView job3 = findViewById(R.id.textView4);
        TextView phone3 = findViewById(R.id.textView5);
        TextView eeemail = findViewById(R.id.textView6);
        Bundle next1 = getIntent().getExtras();
        String next2 = next1.getString("info");
        String next3 = next1.getString("age1");
        String next4 = next1.getString("job1");
        String next5 = next1.getString("phone");
        String next6 = next1.getString("email1");
        name.setText(""+next2);
        age.setText(""+next3);
        job3.setText(""+next4);
        phone3.setText(""+next5);
        eeemail.setText(""+next6);
    }
}